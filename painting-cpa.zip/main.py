class Painting:
    def __init__(self, paintingId, paintingName, paintingPrice, paintingType):
        self.paintingId = paintingId
        self.paintingName = paintingName
        self.paintingPrice = paintingPrice
        self.paintingType = paintingType
        
class ShowRoom:
    def __init__(self,paintingList):
        self.paintingList = paintingList
        
    def getTotalPaintingPrice(self, pType):
        tPrice = 0
        flag =0
        for obj in self.paintingList:
            if obj.pType == pType:
                flag = 1 
                tPrice += obj.paintingPrice
        if flag:
            return tPrice
            
        return None    
                
                
            
    def getPainterWithMaxCountOfPaintings(self):
        dict_of_name ={}
        result = []
        
        for obj in paintingList:
            if obj.paintingName in dict_of_name:
                dict_of_name[obj.paintingName] +=1 
            else:
                dict_of_name[obj.paintingName]= 1 
                
        sort = sorted(nameCount.items(), key = lambda x : x[1])
        val = sort[-1][1]
        for value in sort :
            if val == value[1]:
                result.append(value[0])
        if len(result) > 1 :
            result.sort()
            print(result[0])
        else:
            print(sort[-1][0])
            

n = int(input())
pList = []
for val in range(n):
    paintingId= input().lower()
    paintingName = input().lower()
    paintingPrice= int(input())
    paintingType = input().lower()
        
    pobj = Painting(paintingId,paintingName,paintingPrice,paintingType)
    pList.append(pobj)
        
sobj = ShowRoom(pList)
pType = input().lower()
    
result = sobj.getTotalPaintingPrice(pType)
    
if result:
    print(result)
else:
    print("Painting not Found...")
        
result2 = sobj.getPainterWithMaxCountOfPaintings()
print(result2)
    
            
    
    
    