class Bill:
    def __init__(self,mobileNumber,paymentBill):
        self.mobileNumber= mobileNumber
        self.paymentBill = paymentBill
        
class Mobile:
    def __init__(self,serviceProvider,mobileNumber,dataUsed,paymentMethod):
        self.serviceProvider = serviceProvider
        self.mobileNumber = mobileNumber
        self.dataUsed = dataUsed
        self.paymentMethod = paymentMethod
        
    def calculateBill(self,l):
        m= []
        for i in l:
            if i.serviceProvider == 'airtel':
                b = i.dataUsed*11
                if i.paymentMethod =='paytm':
                    b -=(0.1*b)
            elif i.serviceProvider == 'jio':
                b = i.dataUsed*10
            m.append(Bill(i.mobileNumber,int(b)))
        return m   
        
n = int(input())

my_list =[]

for i in range(n):
    serviceProvider = input()
    mobileNumber = int(input())
    dataUsed = int(input())
    paymentMethod = input()
    my_list.append(Mobile(serviceProvider, mobileNumber, dataUsed, paymentMethod))
m = Mobile('',0,0,'')
m1 = m.calculateBill(my_list)
print(m1)
    
    
    