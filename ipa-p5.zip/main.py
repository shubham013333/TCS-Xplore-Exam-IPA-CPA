class NavalVessel:
    def __init__(self,vesselId,vesselName,noVoyagesPlanned,noVoyagesCom,purpose,classification):
        self.vesselId = vesselId
        self.vesselName = vesselName
        self.noVoyagesPlanned = noVoyagesPlanned
        self.noVoyagesCom = noVoyagesCom
        self.purpose = purpose
        self.classification = classification
        
class Solution:
    def __init__(self,mylist):
        self.mylist = mylist
        
    def findAvgVoyagesByPct(self,per):
        avg = 0
        for i in self.mylist:
            navPer = (i.noVoyagesCom * 100)//noVoyagesPlanned
            if navPer>=per:
                avg = avg + i.noVoyagesCom
        return avg    

    def findVesselByGrade(self,purp):
        res2 =[]
        for i in self.mylist:
            if i.purpose.lower() == purp.lower():
                res2.append(i)
               
        return res2
                    
                
        


n = int(input())
my_arr =[]
for i in range(n):
    vesselId = int(input())
    vesselName = input()
    noVoyagesPlanned = int(input())
    noVoyagesCom = int(input())
    purpose = input()
    
    nv = NavalVessel(vesselId,vesselName,noVoyagesPlanned,noVoyagesCom,purpose,0)
    
    my_arr.append(nv)
per = int(input())
purp = input()
s = Solution(my_arr)

ans1 = s.findAvgVoyagesByPct(per)
ans2 = s.findVesselByGrade(purp)

print(ans1)
for i in ans2:
    navPer = (i.noVoyagesCom * 100)//i.noVoyagesPlanned
    if navPer ==100:
        print(i.vesselName,'%Star')
    elif navPer >=80 and navPer <=99:
        print(i.vesselName,'%Leader')
    elif navPer>=55 and navPer<=79:
        print(i.vesselName,'%Inspirer')
    else:
        print(i.vesselName,'%Striver')
                    