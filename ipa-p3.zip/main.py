class Player:
    def __init__(self,pId,pSkill,pLevel,pPnts):
        self.pId = pId
        self.pSkill = pSkill
        self.pLevel = pLevel
        self.pPnts = pPnts
        
class Solution:
    def __init__(self,mylist):
        self.mylist = mylist
        
    def findPointsForGivenSkill(self,skill):
        res = []
        total =0
        for i in self.mylist:
            if i.pSkill.lower() == skill.lower():
                total = total + i.pPnts
        
        if total>0:
            return total
        else:
            return 0
                
    
    def getPlayerBasedOnLevel(self,level,skill):
        result = []
        for i in self.mylist:
            if i.pLevel.lower() == level.lower() and i.pSkill.lower() == skill.lower() and i.pPnts>=20:
                result.append(i)
        if len(result)>0:
            return result
        else:
            return 0
    
    
n = int(input())
my_arr = []
for i in range(n):
    pId = int(input())
    pSkill = input()
    pLevel = input()
    pPnts = int(input())
    p = Player(pId,pSkill,pLevel,pPnts)
    my_arr.append(p)
    
skill = input() 
level =input()

s = Solution(my_arr)

ans1 = s.findPointsForGivenSkill(skill)
ans2 = s.getPlayerBasedOnLevel(level,skill)

if ans1 == 0:
    print('Not Found!')
else:
    print(ans1)
    
if ans2 == 0:
    print('Null')
for i in ans2:
    print(i.pId)