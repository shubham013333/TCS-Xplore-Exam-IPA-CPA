class Volcano:
    def __init__(self, volcanoName, country, elevation, areaInKmSq,lastEruptionYear):
        self.volcanoName = volcanoName
        self.country = country
        self.elevation =elevation
        self.areaInKmSq = areaInKmSq
        self.lastEruptionYear = lastEruptionYear
        


class Eruption:
    def __init__(self,volcanoList):
        self.volcanoList = volcanoList
        
    def findVolcanoByCountry(volcanoList,vCountry):
        for vol in self.volcanoList:
            if vol.country.lower() == vCountry.lower():
                print(vCountry) 
            else:
                print("No Matching records Found")
                
    def getVolcanoCategorization(volcanoList,vName):
        for vol in self.volcanoList:
            v1 = vol.lastEruptionYear
            y1 = 2021
            v2 = vol.volcanoName
            if ((v1-y) <=25 and v2.lower() == vName.lower()):
                print("High Probability")
            elif ((v1-y) >25 and (v1-y)<=50 and v2.lower() == vName.lower()):
                print("Low Probability")
            elif ((v1==y)and v2.lower() == vName.lower()):
                print("Active")
            elif (v2.lower() != vName.lower()):
                print("No Volcano is available with the given name")
            else:
                print("Inactive")
                
    
    

n = int(input())

vol_list = []

for i in range(n):
    volcanoName = input()
    country = input()
    elevation = int(input())
    areaInKmSq = int(input())
    lastEruptionYear = int(input())
    
    v = Volcano(Volcano, country, elevation, areaInKmSq, lastEruptionYear)
    vol_list.append(v)
    
vCountry = input()
vName = input()
    
e = Eruption(vol_list)
ans = e.findVolcanoByCountry(vol_list,vCountry)
print(ans)
e.getVolcanoCategorization(vol_list,vName)
    
    

