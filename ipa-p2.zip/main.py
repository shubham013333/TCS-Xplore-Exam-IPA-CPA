class Movie:
    def __init__(self, mName, company,genre, budget):
        self.mName = mName
        self.company = company
        self.genre = genre
        self.budget = budget
        
class Solution:
    def __init__(self,mylist):
        self.mylist = mylist
        
    def getMovieByGenre(self,search_genre):
        res =[]
        res2 =[]
        for i in self.mylist:
            if i.genre.lower() == search_genre.lower() and i.budget>=80000000:
                res.append('High Budget Movie')
            elif i.genre.lower() == search_genre.lower() and i.budget<80000000:
                res2.append('Low Budget Movie')
        if 'High' in res:
            return res
        else:
            return res2
n = int(input())

myarray =[]

for i in range(n):
    mName = input()
    company = input()
    genre = input()
    budget = int(input())
    m = Movie(mName,company,genre,budget)
    myarray.append(m)
search_genre = input()    
s = Solution(myarray) 

ans =  s.getMovieByGenre(search_genre)
for i in ans:
    print(i)
    
    