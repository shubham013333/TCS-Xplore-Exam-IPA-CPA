class Associate:
    def __init__(self,attId,name,tech,expInYear):
        self.attId = attId
        self.name = name
        self.tech = tech
        self.expInYear = expInYear
        
class Solution:
    def __init__(self,mylist):
        self.mylist = mylist
        
    def associatesForGivenTechnology(self,search_tech):
        res =[]
        for i in self.mylist:
            if i.tech.lower() == search_tech.lower() and i.expInYear%5==0:
                res.append(i)
        if len(res)>0:
            return res
        else:
            return None
n = int(input())
myarray = []
for i in range(n):
    attId = int(input())
    name = input()
    tech = input()
    expInYear = int(input())
    a = Associate(attId,name,tech,expInYear)
    myarray.append(a)

search_tech = input()

s = Solution(myarray) 

ans = s.associatesForGivenTechnology(search_tech)

if ans==None:
    print('Not Found')
else:
    for i in ans:
        print(i.attId,i.name)