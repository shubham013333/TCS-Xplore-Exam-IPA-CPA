class Payslip:
    def __init__(self,bs,hra,ita):
        self.bs = bs
        self.hra = hra
        self.ita = ita
        
class PaySlipDemo:
    def __init__(self):
        self.a = 10
        
    def getHighestPf(self,list_pay):
        list_p=[]
        for i in list_pay:
            a = i.bs*0.12
            list_p.append(a)
        return int(max(list_p))
            


n = int(input())
list_pay = []

for i in range(n):
    bs = int(input())
    hra = int(input())
    ita = int(input())
    list_pay.append(Payslip(bs,hra,ita))
    
    p = PaySlipDemo()
    p1 = p.getHighestPf(list_pay)
    print(p1)
            
        