class Employee:
    def __init__(self,employee_name,designation,salary,overTimeContribution,overTimeStatus =False):
        self.employee_name = employee_name
        self.designation = designation
        self.salary = salary
        self.overTimeContribution = overTimeContribution
        self.overTimeStatus = overTimeStatus
        
class Organization:
    def __init__ (self,emp_list):
        self.emp_list = emp_list
        
    def checkEmpOverTime(self,overtime):
        for i in self.emp_list:
            if int(sum(i.overTimeContribution.values())) >= int(overtime):
                i.overTimeStatus = True
        return self.emp_list
    def totalBonus(self,overtimehour):
        total =0
        for i in self.emp_list:
            if i.overTimeStatus == 'True':
                total += int(sum(i.overTimeContribution.values()))*overtimehour
                
        return total        

n = int(input())
mylist = []
for i in range(n):
    employee_name = input()
    designation = input()
    salary = int(input())
    mydict ={}
    num = int(input())
    for j in range(num):
        month = input()
        overtime = int(input())
        mydict[month.lower()] = overtime
    e = Employee(employee_name,designation,salary,mydict)
    mylist.append(e)
overtime = int(input())
overtimehour = int(input())
o = Organization(mylist)

ans1 = o.checkEmpOverTime(overtime)
ans2 = totalBonus(overtimehour)

for i in ans1:
    print(i.employee_name,' ',i.overTimeStatus)
    
print(ans2)    
    
    
        
        
        