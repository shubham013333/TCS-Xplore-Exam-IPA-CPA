class Property:
    def __init__(self,propertyType,propertyValue, maxBidPrice):
        self.propertyType = propertyType
        self.propertyValue = propertyValue
        self.maxBidPrice = maxBidPrice
        
class Tender:
    def __init__(self,buyerName, propertyType,bidPrice):
        self.buyerName =buyerName
        self.propertyType = propertyType
        self.bidPrice = bidPrice
        
def bidProperty(pList,Tlist):
    nameList = []
    typeSet = set()
    removeobj = set()
    mydict = {}
    
    for i in Tlist:
        for j in pList:
            if i.propertyType.lower() == j.propertyType.lower():
                if i.propertyType.lower() in mydict:
                    if mydict[i.propertyType][1]<i.bidPrice:
                        mydict[i.propertyType.lower()] = (i.buyerName, i.bidPrice)
                    
                    else:
                        mydict[i.propertyType.lower()]= (i.buyerName,i.bidPrice)
                    
                    if i.bidPrice>=j.propertyValue and i.bidPrice <=j.maxBidPrice:
                    
                        typeSet.add(i.propertyType.lower())
                        removeObj.add(j)
    for ptype in typeSet:
        nameList.append(mydict[ptype][0])
             
    for i in removeobj:
        pList.remove(i)
    
    return nameList    
                   

n = int(input())
mylist = []

for i in range(n):
    propertyType = input()
    propertyValue = int(input())
    maxBidPrice = int(input())
    p = Property(propertyType, propertyValue, maxBidPrice)
    mylist.append(p)
    
n2 = int(input())    
mylist2 = []
for j in range(n2):
    buyerName = input()
    propertyType = input()
    bidPrice = int(input())
    t = Tender(buyerName,propertyType,bidPrice)
    mylist2.append(t)
    

returnValue = bidProperty(mylist,mylist2)
 

if len(returnValue):
    for name in returnValue :
        print(name)
             
else:
    print("Property Not found")

for obj in mylist:
    print(obj.propertyType)    
    
    