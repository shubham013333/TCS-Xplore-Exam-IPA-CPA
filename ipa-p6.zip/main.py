class Sim:
    def __init__(self,iD,company,balance,ratePerSecond,circle):
        self.iD = iD
        self.company = company
        self.balance = balance
        self.ratePerSecond = ratePerSecond
        self.circle = circle
class Solution:
    def __init__(self,mylist):
        self.mylist = mylist
        
    def matchAndSort(self,srch_circle,srch_rate):
        res =[]
        for i in self.mylist:
            if i.circle.lower() == srch_circle.lower() and i.ratePerSecond < srch_rate:
                res.append(i)
           
        return res 
            
n = int(input())
my_arr =[]
for i in range(n):
    iD = int(input())
    company = input()
    balance = int(input())
    ratePerSecond = float(input())
    circle = input()
    
    s = Sim(iD,company,balance,ratePerSecond,circle)
    my_arr.append(s)
srch_circle = input()
srch_rate = float(input())
sol = Solution(my_arr)
ans = sol.matchAndSort(srch_circle,srch_rate)
ans.sort(reverse=True)
for i in ans:
    print(i.iD)