class AutonomousCar:
    def __init__(self,carId, brand,noOfTestsCon,noTestsPassed,env):
        self.carId = carId
        self.brand = brand
        self.noOfTestsCon = noOfTestsCon
        self.noTestsPassed = noTestsPassed
        self.env = env
        #self.grade= grade
        
class Solution:
    def __init__(self,mylist):
        self.mylist = mylist
        
    def findTestPassedByEnv(self,enmt):
        res = []
        total =0
        for i in self.mylist:
            if i.env.lower() == enmt.lower():
                total = total +i.noTestsPassed
        if total>0:
            return total
        else:
            return 0
            
    def updateCarGrade(self,brand):
        res2 = []
        for i in self.mylist:
            if i.brand.lower() == brand.lower():
                res2.append(i)
        return res2            
                
        
    
n = int(input())

my_arr =[]

for i in range(n):
    carId = int(input())
    brand = input()
    noOfTestsCon = int(input())
    noTestsPassed = int(input())
    env = input()
    #grade = input()
    ac = AutonomousCar(carId,brand,noOfTestsCon,noTestsPassed,env)
    my_arr.append(ac)

emnt = input()
brand = input()
s = Solution(my_arr)

ans1 = s.findTestPassedByEnv(emnt)
ans2 = s.updateCarGrade(brand)

print(ans1)

for i in ans2:
    rating = (i.noTestsPassed * 100)//i.noOfTestsCon
    if rating>=80:
        print(i.brand,'::A1')
    else:
        print(i.brand,'::B2')
    
    
    